function [T]=SSStridiag(n,md,sdl,sdu)
% SSStridiag returns a tri-diagonal SSS matrix with semiseparable order 1,
% this matrix is often used in blocks of stiffness matrix and other
% matrices from discretized PDEs
%
% Syntax: T=SSStridiag(n,md,sdl,sdu), n is the number of blocks, md is a
% vector of size 1 X n that contains the entries of the main diagonal, sdl
% is a vector of size 1 X (n-1) that contains the entries of the lower
% sub-diagonal, sdu is a vector of size 1 X (n-1) that contains the entries
% of the upper sub-diagonal
%
% Written by Yue Qiu, 28-11-2012
% Delft Center for System and Control
% Delft University of Technology
%
% Copyright (c) reserved
%
% See also SSSeye, SSSzeros

if nargin~=4
    error('SSStridiag needs 4 input arguments')
end

if ~isequal(n,length(md),length(sdl)+1,length(sdu)+1)
    error('Input vectors should have the suitable length')
end

P=cell(1,n-1);
R=cell(1,n-2);
Q=cell(1,n-1);
D=cell(1,n);
U=cell(1,n-1);
W=cell(1,n-2);
V=cell(1,n-1);

for i=1:n
    if i==1
        D{i}=md(i);
        P{i}=sdl(i);
        Q{i}=1;
        U{i}=sdu(i);
        V{i}=1;
    elseif i==n
        D{i}=md(i);
    else
        D{i}=md(i);
        P{i}=sdl(i);
        R{i-1}=0;
        Q{i}=1;
        U{i}=sdu(i);
        W{i-1}=0;
        V{i}=1;
    end
end

T=SSSbuild(P,R,Q,D,U,W,V);

end

        