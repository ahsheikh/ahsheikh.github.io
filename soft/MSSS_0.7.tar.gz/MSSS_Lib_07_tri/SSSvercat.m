function [X]=SSSvercat(A,B)
% SSSvercat returns the vertical concatenation of 2 SSS matrices A and B,
% i.e., [A;B]
%
% Syntax: X=SSSvercat(A,B), where A and B are SSS matrices. X is the
% permuted[A;B] and X is still an SSS matrix
%
% Written by Yue Qiu, 27-11-2012, modified on 06-12-2012
% Delft Center for System and Control
% Delft University of Technology
%
% Copyright (c) reserved

X=A;

X.P=cellfun(@blkdiag,A.P,B.P,'UniformOutput',false);
X.R=cellfun(@blkdiag,A.R,B.R,'UniformOutput',false);
X.Q=cellfun(@horzcat,A.Q,B.Q,'UniformOutput',false);
X.D=cellfun(@vertcat,A.D,B.D,'UniformOutput',false);
X.U=cellfun(@blkdiag,A.U,B.U,'UniformOutput',false);
X.W=cellfun(@blkdiag,A.W,B.W,'UniformOutput',false);
X.V=cellfun(@horzcat,A.V,B.V,'UniformOutput',false);

X.adds=A.adds+B.adds;    % modify the adds of X

end
        
        
        
        
        
        
        
        
        
        
        
        
