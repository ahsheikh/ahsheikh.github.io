%%%%%%%%%% test function for MSSS_Lib_06 %%%%%%%%%%%%%%%%

clear
clear all

N=2^5;
n=2^2;

pc=zeros(n,n);
pc(1,n)=-1;
P=repmat({pc},1,N/n-1);
R=repmat({zeros(n,n)},1,N/n-2);
Q=repmat({eye(n)},1,N/n-1);
d=gallery('tridiag',n,-1,4,-1);
D=repmat({full(d)},1,N/n);
U=repmat({pc'},1,N/n-1);
W=R;
V=Q;

K=SSSbuild(P,R,Q,D,U,W,V);

Kinv=SSSinv(K);
Kinv2=SSSmatmat(Kinv,Kinv);
Kinv2_app=SSScheckmor_q(Kinv2,4);
kinv2_app=SSS2full(Kinv2_app);
kinv2=SSS2full(Kinv2);
norm(full(kinv2-kinv2_app))

x=randn(N,1);
b=SSSmatvec(K,x);
k=SSS2full(K);
fprintf('this is the sparsity patten of SSS matrix K \n')
figure(1),spy(k)


%%%%%%%%%%%%%%%% test the MOR svd operation %%%%%%%%%%%%%%%%%%
tic
for i=1:200
    K2=SSSmatmat(K,K);
end
t_new=toc

tic
for i=1:200
    K3=SSSmatmat_old(K,K);
end
t_old=toc

%%%%%%%%%%%%%%%%%%%%% test SSSinv %%%%%%%%%%%%%%%
tic
for i=1:150
    Kinv1=SSSinv(K);
end
t_inv_new=toc

tic
for i=1:150
    Kinv2=SSSinv_old(K);
end
t_inv_old=toc

kinv1=SSS2full(Kinv1);
norm(k*kinv1-eye(N))

%%%%%%%%%%%%%%% test SSSmor %%%%%%%%%%%%%%%%%
K2=SSSmatmat(K,K);
K4=SSSmatmat(K2,K2);
K4r=SSScheckmor(K4,4);
k4r=SSS2full(K4r);
norm(full(k4r)-full(k^4))/norm(full(k^4))

%%%%%%%%%%%%% test SSSchol %%%%%%%%%%%%%%%%%%%%%%%%%%%

L=SSSchol(K);
l=SSS2full(L);
ll=chol(kk,'lower');
norm(l-ll);
%%%%%%%%%%%%%% test the LU factorization by SSS computation %%%%%%%%%%%
fprintf('now do the LU factprization of K \n')
[L,U]=SSSLU(K);
l=SSS2full(L);
u=SSS2full(U);
fprintf('the sparsity patten of L is: \n')
figure(2),spy(l)
fprintf('the sparsity patten of U is: \n')
figure(3),spy(u)
[ll,uu]=lu(k);
fprintf('the error for L with SSSLU factorization and LU is %8.3f\n',norm(l-ll))
fprintf('the error for U with SSSLU factorization and LU is %8.3f\n',norm(u-uu))

%%%%%%%%%%%% test the SSSmatmat with the Bx matrix and K matrix %%%%%%%

% this is necessary in the computation of Stokes equation

N=2^8;
P=cell(1,N-1);
R=cell(1,N-2);
Q=cell(1,N-1);
D=cell(1,N);
U=cell(1,N-1);
W=cell(1,N-2);
V=cell(1,N-1);

for i=1:N
    if i==1
        D{i}=[2 -1;-1 2];
        Q{i}=[0;-1];
        P{i}=1;
        U{i}=[0;-1];
        V{i}=1;
    elseif i==N
        D{i}=2;
    else
        P{i}=1;
        Q{i}=-1;
        U{i}=1;
        V{i}=-1;
        D{i}=2;
        W{i-1}=0;
        R{i-1}=0;
    end
end
K2=SSSbuild(P,R,Q,D,U,W,V);

K2inv=SSSinv(K2);
k2inv=SSS2full(K2inv);
k2=SSS2full(K2);
norm(full(k2inv)-k2\eye(N+1))

for i=1:N
    if i==1
        D{i}=[1 2];
        P{i}=1;
        Q{i}=[0;1];
        U{i}=1;
        V{i}=1;
    elseif i==N
        D{i}=2;
    else
        P{i}=1;
        Q{i}=-1;
        U{i}=1;
        V{i}=-1;
        D{i}=2;
        W{i-1}=0;
        R{i-1}=0;
    end
end
Bx=SSSbuild(P,R,Q,D,U,W,V);
S=SSSmatmat(Bx,K2);
bx=SSS2full(Bx);
s=SSS2full(S);
norm(full(s-bx*k2))

S=SSSmatmat(Bx,K2inv);
s=SSS2full(S);
norm(full(s-bx*k2inv))


%%%%%%%%%%%%%%%%%%%% test the forward substitution %%%%%%%%%%%%%%%%%%

b=randn(N,1);
x=SSSforwsub(L,b);
fprintf('the error for the SSSforwsub is %8.4f \n',norm(l*x-b))

%%%%%%%%%%%%%%%%%% test the SSSbacksub %%%%%%%%%%%%%%%%%%%%
y=SSSbacksub(U,b);
fprintf('the error for the SSSbacksub is %8.4f \n',norm(u*y-b))





%%%%%%%%%%%%%%%% test the mat-mat by SSS computation %%%%%%%%%%%%%
KK=SSSmatmat(K,K);
kk=SSS2full(KK);
fprintf('the error between K^2 with SSS computations and K^2 with Matlab computation is %8f\n',norm(kk-k^2))

%%%%%%%%%%%%% test the inversion of the lower-triangular matrix with SSS
%%%%%%%%%%%%% computation %%%%%%%%%%%%%%%%%%%%55
fprintf('now we test the SSSinvlowtri function\n')
Linv=SSSinvlowtri(L);
linv=SSS2full(Linv);
fprintf('the error between Linv with SSS computations and Matlab Computations is %8f\n',norm(linv-inv(ll)))

%%%%%%%%%%%%%%%%%%% test the inversion computation with SSS computation
%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%
fprintf('now we test the SSSinv function \n')
Kinv=SSSinv(K);
kinv=SSS2full(Kinv);
fprintf('the error of kinv between SSS computation and Matlab computation is %8f \n',norm(kinv-inv(k),'fro'))

%%%%%%%%%%%%%%%%% now we test the SSSsize function %%%%%%%%%

[m,n,k,l]=SSSsize(KK);

%%%%%%%%%%%%% test the cells times a scalar %%%%%%%%%
DD=cellfun(@times,D,D,'uni',false);

D2=cellfun(@plus,D,D,'uni',false);

sc=cell(1,N);
[sc{:}]=deal(3);

dD=cellfun(@times,D,sc,'uni',false);

%%%%%%%%%%%% tests the SSS matrix times a scalar %%%%%%%%%%%

a=-2;
K2=SSSmultiplyscalar(K,a);

%%%%%%%%%%%%% test the SSSadd function %%%%%%%%%%%
K3=SSSadd(K,K);








