function [S]=SSSmatmat_old(A,B)
% SSSmatmat returns the result of two SSS matrices product
%
% Syntax: C=SSSmatmat(A,B) where A and B are both SSS matrices and C is
% also an SSS matrix
%
% Written by Yue Qiu, 19-11-2012, modified on 06-12-2012, 05-11-2013
% Delft Center for System and Control
% Delft University of Technology
%
% Copyright (c) reserved

global N
global j


N=A.n;
G=cell(1,N);    % forward recursion
H=cell(1,N);    % backward recursion

k=1;
for i=N:-1:2
    if i==N
        H{i-1}=A.V{i}'*B.P{i};
        G{k+1}=A.Q{k}'*B.U{k};    
    else
        H{i-1}=A.V{i}'*B.P{i}+A.W{i}*H{i}*B.R{i};
        G{k+1}=A.Q{k}'*B.U{k}+A.R{k}*G{k}*B.W{k};
    end
    k=k+1;
end

S=A;

j=1;

[S.P,S.R,S.Q,S.D,S.U,S.W,S.V]=cellfun(@cellmatmat,A.P,A.R,A.Q,A.D,A.U,A.W,A.V,...
    B.P,B.R,B.Q,B.D,B.U,B.W,B.V,G,H,'UniformOutput',false);



    function [p,r,q,d,u,w,v]=cellmatmat(ap,ar,aq,ad,au,aw,av,bp,br,bq,bd,bu,bw,bv,g,h)
        if j==1
            d=ad*bd+au*h*bq';
            p=[];
            r=[];
            q=horzcat(bq,bd'*aq);
            u=horzcat(ad*bu,au);
            w=[];
            v=[];
        elseif j==N
            d=ad*bd+ap*g*bv';
            v=horzcat(bv,bd'*av);
            r=[];
            q=[];
            u=[];
            w=[];
            p=horzcat(ad*bp,ap);
        else            
            u=horzcat(ad*bu+ap*g*bw,au);
            w=[bw zeros(size(bw,1),size(aw,2));av'*bu aw];
            v=horzcat(bv,bd'*av+bq*h'*aw');            
            d=ad*bd+au*h*bq'+ap*g*bv';
            p=horzcat(ad*bp+au*h*br,ap);
            r=[br zeros(size(br,1),size(ar,2));aq'*bp ar];
            q=horzcat(bq,bd'*aq + bv*g'*ar');
        end
        j=j+1;
    end

clear global N
clear global j

S.adds=max(A.adds,B.adds)+1;


end




























