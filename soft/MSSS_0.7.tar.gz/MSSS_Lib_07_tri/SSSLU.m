function [L,U]=SSSLU(A)
% SSSLU do the LU factorization to an SSS matrix A
%
% Syntax: [L,U]=SSSLU(A), where A is an SSS matrix, L is a lower-triangular
% block SSS matrix with identity matrix on the main diagonal block, U is an
% upper-triangular block SSS matrix
%
% Written by Yue Qiu, 20-11-2012, modified on 07-12-2012, 20-12-2012,
% 04-11-2013
% Delft Center for System and Control
% Delft University of Technology
%
% Copyright (c) reserved


rc=cellfun(@size,A.D,'uni',false);
rc1=cat(1,rc{:});

if ~isequal(rc1(:,1),rc1(:,2))
    error('A needs to be an SSS matrix with square diagonal blocks')
end

N=A.n;
% L.n=N;
% U.n=N;
% L.P=A.P;
% L.R=A.R;
% U.W=A.W;
% U.V=A.V;
L=A;
U=A;

for i=1:N
    if i==1
        [L.D{i}, U.D{i}]=lu(A.D{i});
        L.Q{i}=U.D{i}'\A.Q{i};
        L.U{i}=zeros(rc{i}(1),0);
        L.W{i}=[];
        L.V{i}=[];
        U.P{i}=[];
        U.R{i}=[];
        U.Q{i}=zeros(rc{i}(1),0);
        U.U{i}=L.D{i}\A.U{i};
        M=L.Q{i}'*U.U{i};
    elseif i==N
        L.Q{i}=[];
        L.D{i}=A.D{i}-A.P{i}*M*A.V{i}';
        [L.D{i}, U.D{i}]=lu(L.D{i});
        L.U{i}=[];
        L.W{i}=[];
        L.V{i}=zeros(rc{i}(2),0);
        U.P{i}=zeros(rc{i}(1),0);
        U.R{i}=[];
        U.Q{i}=[];
    else
        L.D{i}=A.D{i}-A.P{i}*M*A.V{i}';
        [L.D{i}, U.D{i}]=lu(L.D{i});
        L.Q{i}=U.D{i}'\(A.Q{i}-A.V{i}*M'*A.R{i}');
        U.U{i}=L.D{i}\(A.U{i}-A.P{i}*M*A.W{i});
        M=A.R{i}*M*A.W{i}+L.Q{i}'*U.U{i};
        L.U{i}=zeros(rc{i}(1),0);
        L.W{i}=zeros(0,0);
        L.V{i}=zeros(rc{i}(2),0);
        U.P{i}=zeros(rc{i}(1),0);
        U.R{i}=zeros(0,0);
        U.Q{i}=zeros(rc{i}(2),0);
    end
end

end
        
        
    
    
    
    
