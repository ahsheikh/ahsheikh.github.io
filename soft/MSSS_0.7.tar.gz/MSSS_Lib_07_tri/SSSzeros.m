function [S]=SSSzeros(N,m,n)
% SSSzeros returns an SSS zero matrix
%
% Syntax: S=SSSzeros(N,m,n), where N is the number of SSS blocks, m is
% the arrary that contains the size of rows of the diagonal bolcks, n is
% the arrary that contrins the size of the cols of diagonal blocks.
%
% Written by Yue Qiu, 27-11-2012, modified on 07-12-2012, 04-11-2013
% Delft Center for System and Control
% Delft University of Technology
%
% Copyright (c) reserved
%
% See also SSSsize for the m,n,k,l definition

if nargin~=3
    error('SSSzeros needs 3 input arguments')
end
if ~isequal(N,length(m),length(n))
    error('Input arguments lengths should be competible')
end

if size(m,1)>size(m,2)
    m=m';
end
if size(n,1)>size(n,2)
    n=n';
end
mr=num2cell(m,1);
nc=num2cell(n,1);
one=repmat({1},1,N-1);  % previous is 1
one1=repmat({1},1,N-2); % previous is 1
mrp=mr(2:N);
mru=mr(1:N-1);
ncq=nc(1:N-1);
ncv=nc(2:N);
D=cellfun(@(x,y)zeros(x,y),mr,nc,'uni',false);
P=cellfun(@(x,y)zeros(x,y),mrp,one,'uni',false);
Q=cellfun(@(x,y)zeros(x,y),ncq,one,'uni',false);
U=cellfun(@(x,y)zeros(x,y),mru,one,'uni',false);
V=cellfun(@(x,y)zeros(x,y),ncv,one,'uni',false);
R=cellfun(@(x,y)zeros(x,y),one1,one1,'uni',false);
W=R;

S=SSSbuild(P,R,Q,D,U,W,V);

end
        
        
        
























