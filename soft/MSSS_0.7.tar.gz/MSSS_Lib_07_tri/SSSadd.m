function S=SSSadd(varargin)
% SSSadd returns the result of 2 SSS addition
% SSSadd(A,B) returns the result of A+B, where A and B are two SSS matrices
% Note that the size of A and B should be comptible for matrix-matrix
% addition
%
% Writen by Yue Qiu, 16-11-2012, modified on 06-12-2012, 04-11-2013
% Delft Center for systen and control
% Delft University of Technology
%
% Copyright (c) reserved

% check number of inout arguments
if nargin~=2
    error('SSSadd needs 2 input arguments')
end

A=varargin(1);
A=A{1};
B=varargin(2);
B=B{1};

S=A;

S.D=cellfun(@plus,A.D,B.D,'uni',false);
S.P=cellfun(@horzcat,A.P,B.P,'uni',false);
S.R=cellfun(@blkdiag,A.R,B.R,'uni',false);
S.Q=cellfun(@horzcat,A.Q,B.Q,'uni',false);
S.U=cellfun(@horzcat,A.U,B.U,'uni',false);
S.W=cellfun(@blkdiag,A.W,B.W,'uni',false);
S.V=cellfun(@horzcat,A.V,B.V,'uni',false);
S.adds=A.adds+B.adds+1;

end

        
        
        
