function [S]=SSSbuild(varargin)
% SSSbuild Constructs an SSS matrix
% S=SSSconstruct(P,R,Q,D,U,W,V) uses matrices P, R, Q, D, U, W, V as its
% generators to construct an SSS matrix S. The generators notation is the
% same as Shiv's paper except the conjugate transpose 'H' is replaced by
% the transpose 'T'. These generators should satisfy the following demands:
%
%   D is a 1-by-N cell matrix containing m(i)-by-n(i) matrices where the
%   index satisfies i=1:N, N is the number of blocks
%
%   U is a 1-by-(N-1) cell matrix containing m(i)-by-k(i) matrices where the
%   index satisfies i=1:N-1
%
%   W is a 1-by-(N-2) cell matrix containing k(i-1)-by-k(i) matrices where the
%   index satisfies i=2:N-1
%
%   V is a 1-by-(N-1) cell  matrix containing n(i)-by-k(i-1) matrices where the
%   index satisfies i=2:N
%
%   P is a 1-by-(N-1) cell  matrix containing m(i)-by-l(i) matrices where the
%   index satisfies i=2:N
%
%   R is a 1-by-(N-1) cell  matrix containing l(i+1)-by-l(i) matrices where the
%   index satisfies i=2:N-1
%
%   Q is a 1-by-(N-1) cell  matrix containing n(i)-by-l(i+1) matrices where the
%   index satisfies i=1:N-1
%
% Written by Yue Qiu, 12-11-2012, modified by Yue Qiu on 06-12-2012,
% 01-11-2013
% Delft Institute of Applied Mathematics
% Delft Center for System and Control
% Delft University of technology
%
% Copyright (c) reserved

% check number of input arguments
if(nargin~=7)
    error('SSScontruct needs 7 input arguments P, R, Q, D, U, W, V')
end

% distribute input generators
P=varargin(1);
P=P{1};
R=varargin(2);
R=R{1};
Q=varargin(3);
Q=Q{1};
D=varargin(4);
D=D{1};
U=varargin(5);
U=U{1};
W=varargin(6);
W=W{1};
V=varargin(7);
V=V{1};

% check whether input arguments are cell matrices
if ~iscell(P)
    error('SSS matrix needs P to be cell type')
end
if ~iscell(R)
    error('SSS matrix needs R to be cell type')
end
if ~iscell(Q)
    error('SSS matrix needs Q to be cell type')
end
if ~iscell(D)
    error('SSS matrix needs D to be cell type')
end
if ~iscell(U)
    error('SSS matrix needs U to be cell type')
end
if ~iscell(W)
    error('SSS matrix needs W to be cell type')
end
if ~iscell(V)
    error('SSS matrix needs V to be cell type')
end

% check dimension of the generators to make the generators to be a row cell
% array
if size(P,1)>size(P,2)
    P=P';
end
if size(R,1)>size(R,2)
    R=R';
end
if size(Q,1)>size(Q,2)
    Q=Q';
end
if size(D,1)>size(D,2)
    D=D';
end
if size(U,1)>size(U,2)
    U=U';
end
if size(W,1)>size(W,2)
    W=W';
end
if size(V,1)>size(V,2)
    V=V';
end

% check number of blocks to make sure that generated SSS matrix has at
% least 3 blocks
lenD=length(D);
if lenD<3
    error('generated SSS matrix should have at least 3 blocks')
end
lenP=length(P);
lenR=length(R);
lenQ=length(Q);
lenU=length(U);
lenW=length(W);
lenV=length(V);

% check number of generators blocks are compatible or not
if ~isequal(lenP+1,lenR+2,lenQ+1,lenD,lenU+1,lenW+2,lenV+1)
    error('number of blocks of P,R,Q,D,U,W,V should be comptible')
end


% % check size of generators compatible for multiplication or not
% for i=1:lenD
%     if i==1
%         [sd1,sd2]=size(D{i});
%         [su1,su2]=size(U{i});
%         [sw1,~]=size(W{i});
%         [~,sv2]=size(V{i});
%         [~,sp2]=size(P{i});
%         [~,sr2]=size(R{i});
%         [sq1,sq2]=size(Q{i});
%         if ~isequal(sd1,su1)
%             error('D(%i), U(%i) should have the same number of rows',i,i)
%         end
%         if ~isequal(sd2,sq1)
%             error('The columns of D(%i) should be the same with the rows Q(%i)',i,i)
%         end
%         if ~isequal(su2,sw1,sv2)
%             error('Rows of  W(%i) should be the same as columns of U(%i) and V(%i)',i+1,i,i+1)
%         end
%         if ~isequal(sp2,sr2,sq2)
%             error('Columns of P(%i), R(%i) and Q(%i) are not the same',i+1,i+1,i)
%         end
%     elseif i==lenD
%         [sd1,sd2]=size(D{i});
%         [~,su2]=size(U{i-1});
%         [~,sw2]=size(W{i-2});
%         [sv1,sv2]=size(V{i-1});
%         [sp1,sp2]=size(P{i-1});
%         [sr1,~]=size(R{i-2});
%         [~,sq2]=size(Q{i-1});
%         if ~isequal(sd1,sp1)
%             error('D(%i), P(%i) should have the same number of rows',i,i)
%         end
%         if ~isequal(sd2,sv1)
%             error('The columns of D(%i) should be the same with the rows V(%i)',i,i)
%         end
%         if ~isequal(su2,sw2,sv2)
%             error('The columns of U(%i), W(%i) and V(%i) should be the same',i-1,i-1,i)
%         end
%         if ~isequal(sp2,sr1,sq2)
%             error('The number of columns of P(%i) and Q(%i) and rows of R(%i) are not the same',i,i-1,i-1)
%         end
%     else
%         [sd1,sd2]=size(D{i});
%         [su1,su2]=size(U{i});
%         [sw1,sw2]=size(W{i-1});
%         [sv1,sv2]=size(V{i-1});
%         [sp1,sp2]=size(P{i-1});
%         [sr1,sr2]=size(R{i-1});
%         [sq1,sq2]=size(Q{i});
%         seu2=size(U{i-1},2);
%         sev2=size(V{i},2);
%         seq2=size(Q{i-1},2);
%         sep2=size(P{i},2);
%         if ~isequal(sd1,su1,sp1)
%              error('D(%i), P(%i) and U(%i) should have the same number of rows',i,i,i)
%         end
%         if ~isequal(sd2,sv1,sq1)
%             error('Colums of D(%i) and rows of V(%i) and Q(%i) are not the same',i,i,i)
%         end
%         if ~isequal(su2,sw2,sev2)
%             error('Columns of U(%i), W(%i) and V(%i) are not the same',i,i,i+1)
%         end
%         if ~isequal(seu2,sw1,sv2)
%             error('Columns of U(%i), V(%i) and rows of W(%i) are not the same',i-1,i,i)
%         end
%         if ~isequal(sp2,sr2,seq2)
%             error('Columns of P(%i), R(%i), Q(%i) are not the same',i,i,i-1)
%         end
%         if ~isequal(sep2,sr1,sq2)
%             error('Columns of P(%i), Q(%i) and rows of R(%i) are not the same',i+1,i,i)
%         end
%     end
% end


S=struct;
S.n=lenD;
S.adds=0;

% this is the vectorized code
S.P=[{[]} P];
S.R=[{[]} R {[]}];
S.Q=[Q {[]}];
S.D=D;
S.U=[U {[]}];
S.W=[{[]} W {[]}];
S.V=[{[]} V];

end    
