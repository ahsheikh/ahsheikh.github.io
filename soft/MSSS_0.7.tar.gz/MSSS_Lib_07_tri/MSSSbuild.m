function [S]=MSSSbuild(varargin)
% MSSSbuild buids an MSSS matrix object
%
% Syntax: S=MSSSbuild(P,R,Q,D,U,W,V) where P, R, Q, D, U, W,V are SSS
% matrices and are the generators for MSSS matrix S
%
% Written by Yue Qiu, 27-11-2012
% Delft Center for System and Control
% Delft University of Technology
%
% See also SSSbuild, SSSeye, SSSzeros
%
% Copyright (c) reserved

if nargin~=3
    error('MSSSbuild needs 7 input arguments')
end

% distribute input generators

Q=varargin(1);
Q=Q{1};
D=varargin(2);
D=D{1};
U=varargin(3);
U=U{1};

lenD=length(D);
S=struct;
S.n=lenD;
S.Q=[Q {[]}];
S.D=D;
S.U=[U {[]}];
S.adds=0;
S.msss=1;   % flag of an MSSS matrix

end



















