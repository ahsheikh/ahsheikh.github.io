function [X]=SSShorcat(A,B)
% SSShorcat do the horizontal concatenation of two SSS matrices A and B
%
% Syntax: X=SSShorcat(A,B) do the horizontal concatenation of two SSS
% matrices to make X be the permuted [A B], where A and B are SSS matrices
% and X is still an SSS matrix
%
% Written by Yue Qiu, 27-11-2012, modified on 06-12-2012
% Delft Center for System and Control 
% Delft University of Technology
%
% Copyright (c) reserved

if nargin~=2
    error('SSShorcat needs 2 input arguments')
end

if ~isequal(A.n,B.n)
    error('A and B should have the same number of blocks')
end

X=A;

X.P=cellfun(@horzcat,A.P,B.P,'UniformOutput',false);
X.R=cellfun(@blkdiag,A.R,B.R,'UniformOutput',false);
X.Q=cellfun(@blkdiag,A.Q,B.Q,'UniformOutput',false);
X.D=cellfun(@horzcat,A.D,B.D,'UniformOutput',false);
X.U=cellfun(@horzcat,A.U,B.U,'UniformOutput',false);
X.W=cellfun(@blkdiag,A.W,B.W,'UniformOutput',false);
X.V=cellfun(@blkdiag,A.V,B.V,'UniformOutput',false);

X.adds=A.adds+B.adds;    % modify the adds of X

end


