function [S]=SSSinv(X)
% SSSinv returns the inversion of an SSS matrix
%
% Syntax: B=SSSinv(A), where A and B are all SSS matrices, B=inv(A)
%
% Written by Yue Qiu, 20-11-2012, modified on 18-12-2012, 07-11-2013
% Delft Center for System and Control 
% Delft University of Technology
%
% References: [1] S. Chandrasekaran, P. Dewilde, M. Gu, T. Pals, A.-J. van
% der Veen. Fast stable solvers for Sequentially semi-separable linear
% systems of equations. Lawrence Livermore National Laboratory report,
% 2003.
%
% See also SSSLU, SSSinvlowtri
%
% Copyright (c) reserved


% distribute the unchanged parameters
MN=X.n;

% Now first do LU factorization of X 
[L,U]=SSSLU(X); % do LU decomposition for SSS matrix
Linv=SSSinvlowtri(L);   % compute the inverse of L
TU=SSStranspose(U); % compute the transpose of U to make U' be a lower-triangular SSS matrix for inverting
TUinv=SSSinvlowtri(TU); % compute the inverse of TU
Uinv=SSStranspose(TUinv);   % compute the inverse of U

% Prelocate memory
A=Uinv;
B=Linv;
H=cell(1,MN-1);

for i=MN:-1:2
    if i==MN
        H{i-1}=A.V{i}'*B.P{i};           
    else
        H{i-1}=A.V{i}'*B.P{i}+A.W{i}*H{i}*B.R{i};        
    end    
end

S=A;
S.D=cellfun(@mtimes,A.D,B.D,'uni',false);
D2=cellfun(@mtimes,A.U(1:end-1),H,'uni',false);
BQT=cellfun(@transpose,B.Q(1:end-1),'uni',false);
D2=cellfun(@mtimes,D2,BQT,'uni',false);
S.D(1:end-1)=cellfun(@plus,S.D(1:end-1),D2,'uni',false);

P1=cellfun(@mtimes,A.D(2:end),B.P(2:end),'uni',false);
P2=cellfun(@mtimes,A.U(2:end-1),H(2:end),'uni',false);
P2=cellfun(@mtimes,P2,B.R(2:end-1),'uni',false);
P2=cellfun(@plus,P1(1:end-1),P2,'uni',false);
S.P(2:end-1)=P2;
S.P{end}=P1{end};

S.R=B.R;
S.Q=B.Q;
S.U=A.U;
S.W=A.W;

V1=cellfun(@transpose,B.D(2:end),'uni',false);
V1=cellfun(@mtimes,V1,A.V(2:end),'uni',false);
V2=cellfun(@transpose,H(2:end),'uni',false);
V2=cellfun(@mtimes,B.Q(2:end-1),V2,'uni',false);
AWT=cellfun(@transpose,A.W(2:end-1),'uni',false);
V2=cellfun(@mtimes,V2,AWT,'uni',false);
V2=cellfun(@plus,V1(1:end-1),V2,'uni',false);
S.V(2:end-1)=V2;
S.V{end}=V1{end};

S.adds=max(A.adds,B.adds)+1;


S.adds=X.adds;



end