function [x]=MSSSforwsub(L,b)
% MSSSbacksub returns the forward substitution of a lower-triangular MSSS
% matrix, i.e., x=L^{-1}*b is equivalent with Lx=b;
%
% Syntax: x=MSSSbacksub(L,b), where L is a lower-triagnular MSSS matrix
%
% Written by Yue Qiu, 04-12-2012, modified on 10-12-2012
% Delft center for System and Control 
% Delft University of Technology
%
% See also SSSLU, SSSchol, SSSforwsub
%
% Copyright (c) reserved

[m,n,~,~]=cellfun(@SSSsize,L.D,'uni',false);

n=cellfun(@sum,n,'uni',false);
m=cellfun(@sum,m,'uni',false);
m=[m{:}];
n=[n{:}];
m=cumsum(m);
n=cumsum(n);

x=b;

for i=1:L.n
    if i==1
        bx=b(1:m(i));
        x(1:n(i))=SSSforwsub(L.D{i},bx);
    elseif i==2
        bx=b(m(i-1)+1:m(i));
        xx=x(1:n(i-1));
        QT=SSStranspose(L.Q{i-1});
        xx=SSSmatvec(QT,xx);
        x(n(i-1)+1:n(i))=SSSforwsub(L.D{i},bx-xx);
    else
        bx=b(m(i-1)+1:m(i));
        xx=x(n(i-2)+1:n(i-1));
        QT=SSStranspose(L.Q{i-1});
        xx=SSSmatvec(QT,xx);
        x(n(i-1)+1:n(i))=SSSforwsub(L.D{i},bx-xx);
    end
end
        

end

        

