function [S]=SSS2full(varargin)
% SSS2full returns the unstructured matrix from the SSS matrix
%
% Syntax: SSS2full(A), where A is an SSS matrix
% 
% SSS2full uses the idea that A*I=A, where A is the SSS matrix. The SSS
% matrix-vector multiplication can be implemented in linear computational
% complexity
%
% Written by Yue Qiu, 16-11-2012, modified on 01-11-2013
% Delft Center for System and Control
% Delft University of Technology
%
% Copyright (c) reserved

% check number of input arguments
if nargin~=1
    error('This function needs just 1 input arguments')
end

A=varargin(1);
A=A{1};

rc=cellfun(@size,A.D,'uni',false); % get the size of each elements in cells, i.e., the size of each D generators
rc=cat(1,rc{:});    % cat them in the 1st dimension to make it suitable for sum
row=sum(rc(:,1));
col=sum(rc(:,2));

% generator the identity matrix
I=speye(col);

% initialize full matrix of A as a zero sparse matrix
S=sparse(row,col);

% compute the ith column of full matrix of A by A* the ith column of the
% identity matrix

% this loop could be paralled
parfor i=1:col
    S(:,i)=SSSmatvec(A,I(:,i));
end

end



