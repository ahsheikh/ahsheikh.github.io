function [X]=MSSSvercat(A,B)
% MSSSvercat returns the vertical concatenation of 2 MSSS matrices A and B,
% i.e., [A;B]
%
% Syntax: X=MSSSvercat(A,B), where A and B are MSSS matrices. X is the
% permuted[A;B] and X is still an SSS matrix
%
% Written by Yue Qiu, 26-11-2013
% Delft Institute of Applied Mathematics
% Delft University of Technology
%
% Copyright (c) reserved

X=A;

X.Q(1:end-1)=cellfun(@SSShorcat,A.Q(1:end-1),B.Q(1:end-1),'uni',false);
X.D=cellfun(@SSSvercat,A.D,B.D,'uni',false);
X.U(1:end-1)=cellfun(@SSSvercat,A.U(1:end-1),B.U(1:end-1),'uni',false);


end
        
        
        
        
        
        
        
        
        
        
        
        
