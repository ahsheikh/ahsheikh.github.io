function [x]=SSSbacksub(A,b)
% SSSbacksub returns the backward substitution of a upper-triangular matrix,
% i.e., x=U^{-1}*b is equivalent with Ux=b;
%
% Syntax: x=SSSbacksub(U,b), where U is an upper-triagnular SSS matrix
%
% Written by Yue Qiu, 04-12-2012, modified on 28-11-2013
% Delft Institute of Applied Mathematics
% Delft University of Technology
%
% See also SSSLU, SSSchol
%
% Copyright (c) reserved

N=A.n;
rc=cellfun(@(x)size(x,2),A.D,'uni',false);
rc=[rc{:}];
rc=cumsum(rc);
x=cell(1,N);

for i=N:-1:1
    if i==N
        bx=b(rc(i-1)+1:rc(i));
        x{i}=A.D{i}\bx;
        g=A.V{i}'*x{i};
    elseif i~=1
        bx=b(rc(i-1)+1:rc(i))-A.U{i}*g;
        x{i}=A.D{i}\bx;
        g=A.W{i}*g+A.V{i}'*x{i};
    else
        bx=b(1:rc(i))-A.U{i}*g;
        x{i}=A.D{i}\bx;
    end
end

x=cat(1,x{:});
x=x(:);




end

        

