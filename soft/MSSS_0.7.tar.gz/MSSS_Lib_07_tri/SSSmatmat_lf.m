function [S]=SSSmatmat_lf(A,B)
% SSSmatmat_lf returns the result of two SSS matrices product, where A is a
% lower-triangular SSS matrix and B is a full SSS matrix
%
% Syntax: C=SSSmatmat_lf(A,B) where A and B are both SSS matrices and C is
% also an SSS matrix
%
% Written by Yue Qiu, 20-11-2013
% Delft Center for System and Control
% Delft University of Technology
%
% Copyright (c) reserved


N=A.n;
G=cell(1,N-1);    % forward recursion

k=1;
for i=N:-1:2
    if i==N
        G{k}=A.Q{k}'*B.U{k};    
    else
        G{k}=A.Q{k}'*B.U{k}+A.R{k}*G{k-1}*B.W{k};
    end
    k=k+1;
end

S=A;

S.D=cellfun(@mtimes,A.D,B.D,'uni',false);
D3=cellfun(@mtimes,A.P(2:end),G,'uni',false);
BVT=cellfun(@transpose,B.V(2:end),'uni',false);
D3=cellfun(@mtimes,D3,BVT,'uni',false);
S.D(2:end)=cellfun(@plus,S.D(2:end),D3,'uni',false);

P1=cellfun(@mtimes,A.D(2:end),B.P(2:end),'uni',false);
S.P(2:end)=cellfun(@horzcat,P1,A.P(2:end),'uni',false);

rbr=cellfun(@(x)size(x,1),B.R(2:end-1),'uni',false);
car=cellfun(@(x)size(x,2),A.R(2:end-1),'uni',false);
RZ=cellfun(@(x,y)zeros(x,y),rbr,car,'uni',false);
R1=cellfun(@horzcat,B.R(2:end-1),RZ,'uni',false);
AQT=cellfun(@transpose,A.Q(2:end-1),'uni',false);
R2=cellfun(@mtimes,AQT,B.P(2:end-1),'uni',false);
R2=cellfun(@horzcat,R2,A.R(2:end-1),'uni',false);
S.R(2:end-1)=cellfun(@vertcat,R1,R2,'uni',false);

Q1=cellfun(@transpose,B.D(1:end-1),'uni',false);
Q1=cellfun(@mtimes,Q1,A.Q(1:end-1),'uni',false);
Q2=cellfun(@transpose,G(1:end-1),'uni',false);
Q2=cellfun(@mtimes,B.V(2:end-1),Q2,'uni',false);
ART=cellfun(@transpose,A.R(2:end-1),'uni',false);
Q2=cellfun(@mtimes,Q2,ART,'uni',false);
Q2=cellfun(@plus,Q1(2:end),Q2,'uni',false);
S.Q(2:end-1)=cellfun(@horzcat,B.Q(2:end-1),Q2,'uni',false);
S.Q{1}=[B.Q{1} Q1{1}];

U1=cellfun(@mtimes,A.D(1:end-1),B.U(1:end-1),'uni',false);
U2=cellfun(@mtimes,A.P(2:end-1),G(1:end-1),'uni',false);
U2=cellfun(@mtimes,U2,B.W(2:end-1),'uni',false);
U2=cellfun(@plus,U1(2:end),U2,'uni',false);
S.U(2:end-1)=U2;
S.U{1}=U1{1};

S.W=B.W;
S.V=B.V;

S.adds=max(A.adds,B.adds)+1;

end




























