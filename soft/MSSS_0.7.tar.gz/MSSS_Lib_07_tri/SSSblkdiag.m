function [S]=SSSblkdiag(A,B)
% SSSblkdiag returns the block diagonal concatenation of 2 SSS matrices A
% and B
%
% Syntax: S=SSSblkdiag(A,B,maxorder), where A and B should be SSS matrices and S is
% also a permutation of [A 0;0 B], S is an SSS matrix. maxorder is the
% tunable parameter for MOR
%
% Written by Yue Qiu, 27-11-2012, modified on 06-12-2012, 07-11-2013
% Delft Center for System and Control
% Delft University of Technology
%
% Copyright (c) reserved
%
% See also SSShorcat, SSSvercat


N=A.n;

rcA=cellfun(@size,A.D,'uni',false);
rcA=cat(1,rcA{:});
nda=rcA(:,1);
mda=rcA(:,2);
rcB=cellfun(@size,B.D,'uni',false);
rcB=cat(1,rcB{:});
ndb=rcB(:,1);
mdb=rcB(:,2);
Upperzero=SSSzeros(N,nda,mdb);
Lowerzero=SSSzeros(N,ndb,mda);

X1=SSShorcat(A,Upperzero);
X2=SSShorcat(Lowerzero,B);
S=SSSvercat(X1,X2);

end
