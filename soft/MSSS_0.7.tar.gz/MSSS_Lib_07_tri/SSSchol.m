function [L]=SSSchol(A)
% SSSchol returns the Cholesky factorization of an SSS matrix A
%
% Syntax: L=SSSchol(A,maxorder), where A is an SSS matrix, L is also an SSS
% matrix and A=L*L^T. maxorder is a choice if MOR is necessary
%
% Written by Yue Qiu, 03-12-2012, modified on 06-12-2012, 04-11-2013,
% 28-11-2013
% Delft Institute of Applied Mathematics
% Delft University of Technology
%
% See also SSSLU
%
% Copyright (c) reserved

if ~isstruct(A)
    error('Input A should be an SSS matrix object')
end


L=A;
N=A.n;
rc1=cellfun(@(x)size(x,1),A.D,'uni',false);
rc2=cellfun(@(x)size(x,2),A.D,'uni',false);
one=repmat({0},1,N-1);
L.U(1:end-1)=cellfun(@(x,y)zeros(x,y),rc1(1:end-1),one,'uni',false);
L.V(2:end)=cellfun(@(x,y)zeros(x,y),rc2(2:end),one,'uni',false);
L.W(2:end-1)=cellfun(@(x,y)zeros(x,y),one(1:end-1),one(1:end-1),'uni',false);


for i=1:N
    if i==1
        L.D{i}=chol(A.D{i},'lower');
        L.Q{i}=L.D{i}\A.Q{i};
        M=L.Q{i}'*L.Q{i};
    elseif i==N
        L.D{i}=A.D{i}-A.P{i}*M*A.P{i}';
        L.D{i}=chol(L.D{i},'lower');
    else
        L.D{i}=A.D{i}-A.P{i}*M*A.P{i}';
        L.D{i}=chol(L.D{i},'lower');
        L.Q{i}=L.D{i}\(A.Q{i}-A.P{i}*M'*A.R{i}');
        M=A.R{i}*M*A.R{i}'+L.Q{i}'*L.Q{i};
    end
end

end
        
        
        













