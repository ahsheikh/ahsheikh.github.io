function [S]=SSStranspose_lowtri(varargin)
% SSStranspose returns the transpose of an SSS matrix
%
% Syntax: SSStranspose(A), where A should be an SSS matrix
%
% Written by Yue Qiu, 16-11-2012, modified on 06-12-2012
% Delft Center for System and Control
% Delft University of Technology
%
% Copyright (c) reserved

if nargin~=1
    error('This function needs 1 input arguments')
end

A=varargin(1);
A=A{1};

S.n=A.n;
S.U=A.Q;
S.V=A.P;
S.D=cellfun(@transpose,A.D,'UniformOutput',false);
S.W=cellfun(@transpose,A.R,'UniformOutput',false);

end
