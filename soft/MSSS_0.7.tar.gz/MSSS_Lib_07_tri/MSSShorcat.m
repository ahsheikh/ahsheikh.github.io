function [A]=MSSShorcat(A,B)
% MSSShorcat do the horizontal concatenation of two MSSS matrices A and B
%
% Syntax: X=MSSShorcat(A,B) do the horizontal concatenation of two MSSS
% matrices to make X be the permuted [A B], where A and B are MSSS matrices
% and X is still a MSSS matrix
%
% Written by Yue Qiu, 26-11-2013
% Delft Institute of Applied Mathematics
% Delft University of Technology
%
% Copyright (c) reserved


A.Q(1:end-1)=cellfun(@SSSvercat,A.Q(1:end-1),B.Q(1:end-1),'uni',false);
A.D=cellfun(@SSShorcat,A.D,B.D,'uni',false);
A.U(1:end-1)=cellfun(@SSShorcat,A.U(1:end-1),B.U(1:end-1),'uni',false);


end


