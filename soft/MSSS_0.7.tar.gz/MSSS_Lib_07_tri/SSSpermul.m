function [X]=SSSpermul(n,rowsize)
% SSSpermul returns lower half part of the permutation matrix that has the
% form of X=kron(In,[0m Im]), where In is the identity matrix of size n, n
% is the number of SSS blocks, Im is an identity matrix with size m, m is
% the size of diagonal blocks of SSS matrix, 0m is the zero matrix of size
% m. The returned matrix is an SSS matrix
%
% Syntax: X=SSSpermul(n,rowsize), n is the number of SSS blocks, rowsize is
% half of  the number of rows of the SSS matrix that we want to pill out; X
% is an SSS matrix
%
% Written by Yue Qiu, 22-11-2012, modified on 07-12-2012
% Delft Center for System and Control
% Delft University of Technology
%
% Copyright (c) reserved

if nargin~=2
    error('SSSpermuu needs 2 input arguments')
end

if ~isequal(n,size(rowsize,2))
    error('Rowsize should contain n (%d) columns',n)
end

%% Preallocate memory

P=cell(1,n-1);
R=cell(1,n-2);
Q=cell(1,n-1);
D=cell(1,n);
U=cell(1,n-1);
W=cell(1,n-2);
V=cell(1,n-1);

%% Now, do the contruction

for i=1:n
    if i==1
        D{i}=[zeros(rowsize(i)) eye(rowsize(i))];   
        P{i}=zeros(rowsize(i),0);
        Q{i}=zeros(2*rowsize(i),0);
        U{i}=zeros(rowsize(i),0);         
        V{i}=zeros(2*rowsize(i),0);
    elseif i==n
        D{i}=[zeros(rowsize(i)) eye(rowsize(i))];        
    else
        D{i}=[zeros(rowsize(i)) eye(rowsize(i))];
        P{i}=zeros(rowsize(i),0);
        Q{i}=zeros(2*rowsize(i),0);
        U{i}=zeros(rowsize(i),0);
        V{i}=zeros(2*rowsize(i),0);
        R{i-1}=[];
        W{i-1}=[];
    end
end

X=SSSbuild(P,R,Q,D,U,W,V);

end        
        
        
        