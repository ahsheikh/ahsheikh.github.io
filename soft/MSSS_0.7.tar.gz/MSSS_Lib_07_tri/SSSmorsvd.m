function [A]=SSSmorsvd(A,maxord)
% SSSmorsvd do the model order reduction of SSS matrices based on the
% algorithms proposed in Shiv and Patrick's paper. It is implemented by
% doing SVD factorization to the Hankel blocks.
%
% Syntax: S=SSSmorsvd(A,maxord), where A is an SSS matrix, S is the reduced
% SSS matrix, in which the upper generators are reduced.
%
% Written by Yue Qiu, 12-12-2012, 06-11-2013
% Delft Center for System and Control
% Delft University of Technology
% 
% See also SSSmor
%
% Copyright (c) reserved


nr=maxord;  % nr is the reduced generator size
n=A.n;

Hhat=zeros(size(A.W{2},1));
nu=cellfun(@(X)size(X,1),A.U(1:end-1),'uni',false);
% Now, perform the left proper form
for i=1:n-1
    H=[Hhat;A.U{i}];
    [U,W,V]=svd(H,0);
    r=min(size(W));
    A.U{i}=U(end-nu{i}+1:end,:);
    A.V{i+1}=A.V{i+1}*V*W';
    if i~=1
        A.W{i}=U(1:r,:);
    end
    if i~=n-1
        Hhat=W*V'*A.W{i+1};
    end
end

Ghat=zeros(size(A.W{n-1},2));
nv=cellfun(@(X)size(X,1),A.V(2:end),'uni',false);
% Now, perform the right proper form
for i=n:-1:2
    G=[A.V{i};Ghat'];
    [U,W,V]=svd(G,0);
    A.V{i}=U(1:nv{i-1},:);
    A.U{i-1}=A.U{i-1}*V*W';
    if i~=n
        A.W{i}=U(nv{i-1}+1:end,:)';
    end
    if i~=2
        Ghat=A.W{i-1}*V*W';
    end    
end



for i=1:n
    if i==1
        A.U{i}=A.U{i}(:,1:nr);
    elseif i==n
        A.V{i}=A.V{i}(:,1:nr);
    else
        A.U{i}=A.U{i}(:,1:nr);
        A.W{i}=A.W{i}(1:nr,1:nr);
        A.V{i}=A.V{i}(:,1:nr);
    end
end
        
end

