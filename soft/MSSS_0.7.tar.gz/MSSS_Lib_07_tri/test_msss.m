clear
clear all

N=2^4;
n=2^2;

% pc=zeros(n,n);
% pc(1,n)=-1;
% D=repmat({pc},1,N/n-1);
% R=repmat({zeros(n,n)},1,N/n-2);
% Q=repmat({eye(n)},1,N/n-1);
% d=gallery('tridiag',n,-1,4,-1);
% D=repmat({full(d)},1,N/n);
% U=repmat({pc'},1,N/n-1);
% W=R;
% V=Q;
% 
% K=SSSbuild(D,R,Q,D,U,W,V);
% 
% I=SSSeye(N/n,n*ones(1,N/n));
% mI=SSSmultiplyscalar(I,-1);
% Z=SSSzeros(N/n,n*ones(1,N/n),n*ones(1,N/n));
% 
% D=repmat({I},1,N-1);
% R=repmat({Z},1,N-2);
% Q=repmat({mI},1,N-1);
% D=repmat({K},1,N);
% U=Q;
% W=R;
% V=D;
% 
% A=MSSSbuild(D,R,Q,D,U,W,V);
% x=ones(N^2,1);
% 
% AA=MSSSmatmat(A,A);
% aa=MSSS2full(AA);
% a=MSSS2full(A);
% norm(full(aa-a^2))
% 
% AAq=MSSSmatmat_q(A,A);
% aaq=MSSS2full(AAq);
% norm(full(aaq-a^2))


%% the following codes test the permutatation of MSSS & SSS blocks
%%%%%%%%%% to make it suitable for the computation of Stokes equation
%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

P=cell(1,N/n-2);
R=cell(1,N/n-3);
Q=cell(1,N/n-2);
D=cell(1,N/n-1);
U=cell(1,N/n-2);
W=cell(1,N/n-3);
V=cell(1,N/n-2);

pc=zeros(n,2*n);
pc(1,2*n)=-1;
pc1=zeros(n,n);
pc1(1,n)=-1;
P=repmat({eye(n)},1,N/n-2);
R=repmat({zeros(n,n)},1,N/n-3);
Q{1}=pc';
Q(2:end)=repmat({pc1'},1,N/n-3);
d=gallery('tridiag',n,-1,4,-1);
d1=gallery('tridiag',2*n,-1,4,-1);
D{1}=full(d1);
D(2:end)=repmat({full(d)},1,N/n-2);
U=Q;
W=R;
V=P;

K=SSSbuild(P,R,Q,D,U,W,V);
k=SSS2full(K);
spy(k)
% Kinv=SSSinv(K);
% kinv=SSS2full(Kinv);

[m,~,~,~]=SSSsize(K);
IH=SSSeye(N/n-1,m);
IH=SSSmultiplyscalar(IH,-1);
RZ=SSSzeros(N/n-1,m,m);
% ih=SSS2full(IH);
% spy(ih)

DH1=SSShorcat(K,IH);
% dh1=SSS2full(DH1);
% spy(dh1)
DH2=SSShorcat(IH,K);
DH1=SSSvercat(DH1,DH2);
% dh1=SSS2full(DH1);
% spy(dh1)
D=cell(1,N-1);
D{1}=DH1;
D(2:end)=repmat({K},1,N-2);
P=repmat({IH},1,N-2);
R=repmat({RZ},1,N-3);
Q=cell(1,N-2);
Q{1}=SSShorcat(RZ,IH);
Q{1}=SSStranspose(Q{1});
Q(2:end)=repmat({IH},1,N-3);
U=Q;
W=R;
V=P;

KH=MSSSbuild(P,R,Q,D,U,W,V);
kh=MSSS2full(KH);
% spy(kh)

%% test the inversion of an MSSS matrix with own and old MOR %%%%%%%%%%%%
KHinv=MSSSinv(KH);
khinv=MSSS2full(KHinv);

KHinv_q=MSSSinv_q(KH);
khinv_q=MSSS2full(KHinv_q);

%% test back-subsitution and forward-substitution and the accuracy of both MOR

x=rand(N^2,1);
[LKH,UKH]=MSSSLU(KH,8); % LU with standard MOR
y=MSSSforwsub(LKH,x);
y=MSSSbacksub(UKH,y);
z=MSSSmatvec(KHinv,x);

w=kh\x;
norm(w-y)
norm(w-z)

[LKHq,UKHq]=MSSSLU_q(KH,8); % LU with own MOR
y1=MSSSforwsub(LKHq,x);
y1=MSSSbacksub(UKHq,y1);
z1=MSSSmatvec(KHinv_q,x);

norm(w-y1)
norm(w-z1)

%%%%%%%%%%%% test MSSSmatvec %%%%%%%%%%%%%%%%%
% tic
% for i=1:50
%     b=MSSSmatvec(A,x);
% end
% t_new_mat_vec=toc
%
% tic
% for i=1:50
%     c=MSSSmatvec_old(A,x);
% end
% t_old_mat_vec=toc



% y=ones(N,1);
% c=SSSmatvec(K,y);
%

%%%%%%%%%%%% test MSSSchol and SSSmor %%%%%%%%%%%%%%
% a=MSSS2full(A);
% la=chol(a,'lower');
% 
% tic
% L=MSSSchol(A,4);
% t_conv_chol=toc
% l=MSSS2full(L);
% 
% tic
% L1=MSSSchol_q(A,4);
% t_q_chol=toc
% l1=MSSS2full(L1);
% 
% x=rand(N^2,1);
% y1=MSSSforwsub(L,x);
% y2=MSSSforwsub(L1,x);
% y3=l\x;
% y4=l1\x;
% y5=la\x;
% 
% norm(y1-y5)/norm(y5)
% norm(y2-y5)/norm(y5)
% norm(y3-y5)/norm(y5)
% norm(y4-y5)/norm(y5)

%
% norm(full(l)-chol(a,'lower'))
%
%
% norm(full(l1)-chol(a,'lower'))

% norm(full(l-l1))

%%%%%%%%%%%%%%% test MSSSLU %%%%%%%%%%%%%%%%


% a=MSSS2full(A);
% [la,ua]=lu(a);

% tic
% [L,U]=MSSSLU(A,4);
% t_conv_lu=toc
% 
% tic
% [L1,U1]=MSSSLU_q(A,5);
% t_q_lu=toc

% l=MSSS2full(L);
% u=MSSS2full(U);
% 
% l1=MSSS2full(L1);
% u1=MSSS2full(U1);



% tic
% L1=MSSSchol_q(A,4);
% t_q_chol=toc
% l1=MSSS2full(L1);

% B=A;





