function [S]=SSSminus(varargin)
% SSSminus returns the result of A-B where A and B are both SSS matrices
% 
% Syntax: SSSminus(A,B), where A and B are both SSS matrices.
%
% Written by Yue Qiu, 16-11-2012
% Delft Center for System and Control
% Delft University of Technogy
%
% Copyright (c) reserved

A=varargin(1);
B=varargin(2);
A=A{1};
B=B{1};

B=SSSmultiplyscalar(B,-1); % compute -B
S=SSSadd(A,B); % compute A+(-B) to get A-B

end