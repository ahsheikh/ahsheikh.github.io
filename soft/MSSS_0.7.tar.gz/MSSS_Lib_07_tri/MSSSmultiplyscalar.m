function [A]=MSSSmultiplyscalar(A,alpha)
% MSSSmultiplyscalar returns the result of the matrix multiplied by a
% scalar
%
% Syntax: S=MSSSmultiplyscalar(A,alpha), A is an MSSS matrix and alpha is a
% scalar. The returned S is an MSSS matrix
%
% Written by Yue Qiu, 27-11-2012, modified on 06-12-2012, 08-11-2013
% Delft Center for System and Control
% Delft University of Technology
%
% Copyright (c) reserved
%
% See also SSSmultiplyscalar

Alpha=repmat({alpha},1,A.n);
A.D=cellfun(@SSSmultiplyscalar,A.D,Alpha,'uni',false);
A.Q(1:end-1)=cellfun(@SSSmultiplyscalar,A.Q(1:end-1),Alpha(1:end-1),'uni',false);
A.U(1:end-1)=cellfun(@SSSmultiplyscalar,A.U(1:end-1),Alpha(1:end-1),'uni',false);
end
 
 

