function [m,n]=MSSSsize(A)
% MSSSsize returns the size of an MSSS matrix
%
% Syntax: [m,n,k,l]=MSSSsize(A), A is an MSSS matrix, m is the cell matrix
% of size 1 X N that contains the size of rows of D_i where D_i is an SSS
% matrix, n is a cell matrix of size 1 X N that contains the size of col
% size of SSS matrix D_i, k is a cell matrix of 1 X (N-1) that contrains
% size of SSS matrix W_i and l is a cell matrix of 1 X (N-1) that contains
% the size of SSS matrix R_i 
%
% Written by Yue Qiu, 27-11-2012, modified on 06-12-2012, 07-11-2013
% Delft Center for System and Control
% Delft University of Technology
%
% Copyright (c) reserved
%
% See also SSSsize

[m,n,~,~]=cellfun(@SSSsize,A.D,'uni',false);    

end
    