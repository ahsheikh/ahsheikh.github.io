function [x]=SSSforwsub(A,b)
% SSSbacksub returns the forward substitution of a lower-triangular matrix,
% i.e., x=L^{-1}*b is equivalent with Lx=b;
%
% Syntax: x=SSSbacksub(L,b), where L is a lower-triagnular SSS matrix
%
% Written by Yue Qiu, 04-12-2012, modified on 28-11-2013
% Delft center for System and Control
% Delft University of Technology
%
% See also SSSLU, SSSchol, SSSbacksub
%
% Copyright (c) reserved

N=A.n;
nc=cellfun(@(x)size(x,2),A.D,'uni',false);      % get number of columns of the diagonal blocks of A
nc=cat(1,nc{:});        % from cell to normal vector
nc=cumsum(nc);      % compute the cumsum of the vector to make it suitable for indexing of the vector
x=cell(1,N);

for i=1:N
    if i==1
        x{i}=A.D{i}\b(1:nc(1));
        g=A.Q{i}'*x{i};
    elseif i~=N
        x{i}=A.D{i}\(b(nc(i-1)+1:nc(i))-A.P{i}*g);
        g=A.R{i}*g+A.Q{i}'*x{i};
    else
        x{i}=A.D{i}\(b(nc(i-1)+1:nc(i))-A.P{i}*g);
    end
end

x=cat(1,x{:});
x=x(:);

end

        

