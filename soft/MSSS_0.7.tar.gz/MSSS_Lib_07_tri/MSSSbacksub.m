function [x]=MSSSbacksub(U,b)
% MSSSbacksub returns the backward substitution of a upper-triangular MSSS
% matrix, i.e., x=U\b is equivalent with Ux=b;
%
% Syntax: x=MSSSbacksub(U,b), where U is a upper-triagnular MSSS matrix
%
% Written by Yue Qiu, 04-12-2012, modified on 10-12-2012
% Delft Institute of Applied Mathematics
% Delft University of Technology
%
% See also SSSLU, SSSchol, SSSforwsub
%
% Copyright (c) reserved

[m,n,~,~]=cellfun(@SSSsize,U.D,'uni',false);
n=cellfun(@sum,n,'uni',false);
m=cellfun(@sum,m,'uni',false);
m=[m{:}];
n=[n{:}];
m=cumsum(m);
n=cumsum(n);
x=b;

for i=U.n:-1:1
    if i==U.n
        bx=b(m(i-1)+1:m(i));
        x(n(i-1)+1:n(i))=SSSbacksub(U.D{i},bx);
    elseif i==1
        bx=b(1:m(i));
        xx=x(n(i)+1:n(i+1));
        xx=SSSmatvec(U.U{i},xx);
        bx=bx-xx;
        x(1:n(i))=SSSbacksub(U.D{i},bx);
    else
        bx=b(m(i-1)+1:m(i));
        xx=x(n(i)+1:n(i+1));
        xx=SSSmatvec(U.U{i},xx);
        bx=bx-xx;
        x(n(i-1)+1:n(i))=SSSbacksub(U.D{i},bx);
    end
end
        

end

        

