function [S]=SSSeye(N,m)
% SSSeye returns an SSS identity matrix
%
% Syntax: S=SSSeye(N,m), where N is the number of SSS blocks, m is an
% array of N X 1 that contains the row size of the diagonal blocks.
%
% Written by Yue Qiu, 27-11-2012, modified on 07-12-2012, 04-11-2013
% Delft Center for System and Control
% Delft University of Technology
%
% Copyright (c) reserved

if size(m,1)>size(m,2)
    m=m';
end
CM=num2cell(m,1);
CO=repmat({0},1,N-1);

D=cellfun(@(x)eye(x),CM,'uni',false);
P=cellfun(@(x,y)zeros(x,y),CM(2:N),CO,'uni',false);
R=cellfun(@(x,y)zeros(x,y),CO(1:N-2),CO(1:N-2),'uni',false);
Q=cellfun(@(x,y)zeros(x,y),CM(1:N-1),CO,'uni',false);
U=Q;
W=R;
V=P;

S=SSSbuild(P,R,Q,D,U,W,V);

end
        
        