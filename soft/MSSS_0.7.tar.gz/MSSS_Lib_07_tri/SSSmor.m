function Y=SSSmor(S,maxorder)
% function that do MOR for SSS matrices by MOR to LTV system using low-rank
% approximation approach
%
% Syntax: Y=SSSmor(S,nr) returns a reduced SSS matrix, S is the SSS natrix
% that needs to be reduced, nr is the maximum allowable semiseparable order
%
% Writen by Yue Qiu, 15-11-2012, modified on 07-12-2012, 07-11-2013
% Delft Center for System and Control
% Delft University of Technology
%
% Copyright (c) reserved

% initialize the Controllability Gramian and Observability Gramian

alpha=1e-14;
nnr=maxorder;
len=S.n;
Gctr=cell(1,len);
Gobs=cell(1,len+1);
N1=size(S.R{2},1);
N2=size(S.R{len-1},1);
Gctr{1}=zeros(N1,nnr);
Gobs{len+1}=zeros(N2,nnr);

k=2;
for i=len:-1:2
    if i==len
        [U_o,Sigma_o,~]=svd([S.P{i}' Gobs{i+1}],0);
        Gobs{i}=U_o(:,1:nnr)*Sigma_o(1:nnr,1:nnr);
        [U_c,Sigma_c,~]=svd([S.Q{k-1}' Gctr{k-1}],0);
        Gctr{k}=U_c(:,1:nnr)*Sigma_c(1:nnr,1:nnr);
    else
        [U_o,Sigma_o,~]=svd([S.P{i}' S.R{i}'*Gobs{i+1}],0);
        Gobs{i}=U_o(:,1:nnr)*Sigma_o(1:nnr,1:nnr);
        [U_c,Sigma_c,~]=svd([S.Q{k-1}' S.R{k-1}*Gctr{k-1}],0);
        Gctr{k}=U_c(:,1:nnr)*Sigma_c(1:nnr,1:nnr);
    end
    k=k+1;
end

Gc=Gctr(2:len);
Go=Gobs(2:len);
% [Pileft,Piright]=cellfun(@cellprojection,Gc,Go,'UniformOutput',false);
% 
%     function [pl,pr]=cellprojection(gc,go)
%         [u,sigma,v]=svd(gc'*go);
%         u=u(:,1:nnr);
%         v=v(1:nnr,:);
%         d=diag(sigma);
%         d(d<eps)=eps;
%         sigma=diag(d);
%         pl=(go*v*sigma^(-1/2))';
%         pr=gc*u*sigma^(-1/2);
%     end

GcT=cellfun(@transpose,Gc,'uni',false);
G=cellfun(@mtimes,GcT,Go,'uni',false);
[u,sigma,v]=cellfun(@svd,G,'uni',false);
d=cellfun(@diag,sigma,'uni',false);
ind=cellfun(@(x)x<alpha,d,'uni',false);
d=cellfun(@(x,y)x+1*y.*(alpha-x),d,ind,'uni',false);
d=cellfun(@(x)x.^(-1/2),d,'uni',false);
sigma=cellfun(@diag,d,'uni',false);
Pileft=cellfun(@mtimes,Go,v,'uni',false);
Pileft=cellfun(@mtimes,Pileft,sigma,'uni',false);
Pileft=cellfun(@transpose,Pileft,'uni',false);
Piright=cellfun(@mtimes,Gc,u,'uni',false);
Piright=cellfun(@mtimes,Piright,sigma,'uni',false);

Y=S;
Y.P(2:end)=cellfun(@mtimes,S.P(2:end),Piright,'uni',false);
PilT=cellfun(@transpose,Pileft,'uni',false);
Y.Q(1:end-1)=cellfun(@mtimes,S.Q(1:end-1),PilT,'uni',false);
Y.R(2:end-1)=cellfun(@mtimes,Pileft(2:end),S.R(2:end-1),'uni',false);
Y.R(2:end-1)=cellfun(@mtimes,Y.R(2:end-1),Piright(1:end-1),'uni',false);
Y.adds=0;

end




