function [S]=MSSStranspose(A)
% MSSStranspose gets the transpose of an MSSS matrix
% 
% Syntax: S=MSSStranspose(A), where A is an MSSS matrix and S=A' is also an
% MSSS matrix
%
% Written by Yue Qiu, 29-11-2012, modified on 10-12-2012, 08-11-2013
% Delft Center for System and Control
% Delft University of Technology
%
% See also SSStranspose%
% Copyright (c) reserved

S.n=A.n; 
S.Q=A.U;
S.U=A.Q;
S.D=cellfun(@SSStranspose,A.D,'uni',false);


end
         

