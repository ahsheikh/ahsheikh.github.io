function [S]=SSStranspose_uptri(A)
% SSStranspose_uptri returns the transpose of an SSS matrix
%
% Syntax: SSStranspose_uptri(A), where A should be an SSS matrix
%
% Written by Yue Qiu, 16-11-2012, modified on 06-12-2012
% Delft Center for System and Control
% Delft University of Technology
%
% Copyright (c) reserved

S.n=A.n;
S.P=A.V;
S.Q=A.U;
S.D=cellfun(@transpose,A.D,'UniformOutput',false);
S.R=cellfun(@transpose,A.W,'UniformOutput',false);

end
