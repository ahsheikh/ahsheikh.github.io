function [X]=SSScheckmor(S,nr)
% Check whether it is necessary to do model order reduction for SSS matrices
%
% input arguments: S is the SSS matrix that generators need to be reduced,
% nr is the maximum allowable reduced order for SSS matrices
%
% Writen by Yue Qiu, 15-11-2012, modified on 07-12-2012
% Delft Center for System and Control
% Delft University of technology
%
% Copyright (c) reserved

% nl=size(S.R{2},1);
% nu=size(S.W{2},1);
% maxorder=nr; % maxorder is the maximum semiseparable order 
% 
% % set default X1 and X2
% X1=S;
% X2=SSStranspose(S);
% 
% % check whether it is necessary to do MOR
% if nl>maxorder 
%     X1=SSSmor(S,maxorder); % do MOR to the lower triangular part
% end
% 
% if nu>maxorder 
%     X2=SSSmor(X2,maxorder); % do MOR to the upper triangular part
% end
% 
% % distribute the reduced generators to the lower triagnular part
% X=X1; 
% 
% % distribute the reduced generators to the upper triangular part
% X.U=X2.Q;
% X.W=cellfun(@transpose,X2.R,'UniformOutput',false);
% X.V=X2.P;
% 
% % distribute the unreduced diagonal part 
% X.D=S.D;
% X.n=S.n;
% X.adds=pi;  % pi is the symbol that shows this SSS matrix has been reduced

%%%%%%%%%%%%%%%%%% Now this is the MOR proposed by Shiv and Patrick %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nl=size(S.R{2},1);
nu=size(S.W{2},1);
maxorder=nr; % maxorder is the maximum semiseparable order 

X1=S;
X2=SSStranspose(S);

if nu>maxorder
    X1=SSSmorsvd(S,maxorder);
end

if nl>maxorder
    X2=SSSmorsvd(X2,maxorder);
end

X=X1;
X.D=S.D;
X.P=X2.V;
X.R=cellfun(@transpose,X2.W,'UniformOutput',false);
X.Q=X2.U;
X.n=S.n;
X.adds=pi; 


end
