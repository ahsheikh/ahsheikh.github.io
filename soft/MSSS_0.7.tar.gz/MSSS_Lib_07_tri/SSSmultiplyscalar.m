function [S]=SSSmultiplyscalar(A,alpha)
% SSSmulplityscalar function returns the result of an SSS matrix multiplied
% by a scalar
%
% Syntax: S=SSSmultiplyscalar(A,alpha), A should be an SSS matrix and alpha
% is a scalar. A should be the first scalar while alpha is the second
% scalar. The returned matrix S should be an SSS matrix.
%
% written by Yue Qiu, 16-11-2012, modified on 06-12-2012, 04-11-2013
% Delft Center for System and Control
% Delft University of technology
%
% Copyright (c) reserved

Alpha=cell(1,A.n);
[Alpha{:}]=deal(alpha);
S=A;

S.P=cellfun(@times,A.P,Alpha,'uni',false);
S.D=cellfun(@times,A.D,Alpha,'uni',false);
S.V=cellfun(@times,A.V,Alpha,'uni',false);

end
