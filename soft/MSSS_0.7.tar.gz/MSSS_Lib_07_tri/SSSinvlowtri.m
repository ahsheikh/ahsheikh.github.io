function [S]=SSSinvlowtri(X)
% SSSinvlowtri do the inversion of a lower-triangular SSS matrix
%
% Syntax: S=SSSinvlowtri(X), where X is a lower-triangular SSS matrix, S is
% also a lower-triangular SSS matrix
%
% Written by Yue Qiu, 20-11-2012, modified on 06-12-2012, 04-11-2013
% Delft Center for System and Control
% Delft University of Technology
%
% References: [1] S. Chandrasekaran, P. Dewilde, M. Gu,T. Pals, A.-J. van
% der Veen. Fast stable solvers for Sequentially semi-separable linear
% systems of equations. Lawrence Livermore National Laboratory report,
% 2003.
%
% Copyright (c) reserved

rc1=cellfun(@(x)size(x,1),X.D,'uni',false);
rc2=cellfun(@(x)size(x,2),X.D,'uni',false);

if (~isequal(rc1,rc2))
    error('You should invert a square lower-triangular Matrix')
end

N=X.n;
one=repmat({-1},1,N-1);
S=X;
I=cellfun(@(x,y)eye(x,y),rc1,rc2,'uni',false);

S.D=cellfun(@mldivide,X.D,I,'uni',false);
S.P(2:end)=cellfun(@mtimes,S.D(2:end),X.P(2:end),'uni',false);
S.P(2:end)=cellfun(@times,S.P(2:end),one,'uni',false);
QT=cellfun(@transpose,X.Q,'uni',false);
S.R(2:end-1)=cellfun(@mtimes,QT(2:end-1),S.D(2:end-1),'uni',false);
S.R(2:end-1)=cellfun(@mtimes,S.R(2:end-1),X.P(2:end-1),'uni',false);
S.R(2:end-1)=cellfun(@minus,X.R(2:end-1),S.R(2:end-1),'uni',false);
DT=cellfun(@transpose,S.D,'uni',false);
S.Q(1:end-1)=cellfun(@mtimes,DT(1:end-1),X.Q(1:end-1),'uni',false);


end


