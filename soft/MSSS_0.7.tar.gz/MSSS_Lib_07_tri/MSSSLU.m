function [L,U]=MSSSLU(A,maxord)
% MSSSchol returns the LU factorization of an MSSS matrix A
%
% Syntax: [L,U]=MSSSchol(A), where A should be an MSSS matrix and L is also an
% MSSS matrix and A=L*U
%
% Written by Yue Qiu, 03-12-2012, modified on 17-12-2012, 20-12-2012,
% 08-11-2013
% Delft Center for System and Control
% Delft University of Technology
%
% See also MSSSLU, SSSchol, SSSLU
%
% Copyright (c) reserved

L.n=A.n;
U.n=A.n;

for i=1:A.n
    if i==1
        [L.D{i},U.D{i}]=SSSLU(A.D{i});
        L.Q{i}=SSSinvuptri(U.D{i});
        L.Q{i}=SSStranspose(L.Q{i});
        L.Q{i}=SSSmatmat_lf(L.Q{i},A.Q{i});
        U.U{i}=SSSinvlowtri(L.D{i});
        U.U{i}=SSSmatmat_lf(U.U{i},A.U{i});
        M=SSStranspose(L.Q{i});
        M=SSSmatmat(M,U.U{i});
        M=SSScheckmor(M,maxord);
        
    elseif i~=A.n        
        L.D{i}=SSSminus(A.D{i},M);
        [L.D{i},U.D{i}]=SSSLU(L.D{i});
        
        L.Q{i}=SSSinvuptri(U.D{i});
        L.Q{i}=SSStranspose(L.Q{i});
        L.Q{i}=SSSmatmat_lf(L.Q{i},A.Q{i});
        
        U.U{i}=SSSinvlowtri(L.D{i});
        U.U{i}=SSSmatmat_lf(U.U{i},A.U{i});    
        
        M=SSStranspose(L.Q{i});
        M=SSSmatmat(M,U.U{i});
        M=SSScheckmor(M,maxord);
    else        
        L.D{i}=SSSminus(A.D{i},M);
        [L.D{i},U.D{i}]=SSSLU(L.D{i});
    end
end
        
        
        
        
end        
