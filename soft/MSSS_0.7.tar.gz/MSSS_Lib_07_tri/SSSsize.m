function [m,n,k,l]=SSSsize(A)
% SSSsize(A) returns the size of all generators of the SSS matrix A
%
% Syntax: [m,n,k,l]=SSSsize(A), where A should be an SSS matrix, this
% function has 4 return variables where m is an arrary of 1 X N that stores
% the number of rows of each block; n is an arrary of 1 X N that stores the
% number of columns of every blocks; k is an arrary of 1 X (N-1) that
% stores the size of W_i and l is an arrary of 1 X (N-1) that contain the
% size of R_i. N is the number of generator blocks of A.
%
% Written by Yue Qiu, 16-11-2012 
% Delft Center for System and Control 
% Delft University of Technology
%
% Copyright (c) reserved

rc=cellfun(@size,A.D,'uni',false);
rc=cat(1,rc{:});
m=rc(:,1);
n=rc(:,2);

rc=cellfun(@size,A.P,'uni',false);
rc=cat(1,rc{:});
l=rc(:,2);
rc=cellfun(@size,A.U,'uni',false);
rc=cat(1,rc{:});
k=rc(:,2);

end
        
        
        
        
        
        
        


