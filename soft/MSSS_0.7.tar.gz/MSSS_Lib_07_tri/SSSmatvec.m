function [b]=SSSmatvec(A,x)
% SSSmatvec returns the SSS matrix-vector product with order N where N is
% the number of SSS blocks
%
% Syntax: b=SSSmatvec(A,x), where A is an SSS matrix and x is a vector, the
% size of A and b should be compitible for matrix-vector product
%
% Written by Yue Qiu, 19-11-2012, modified on 06-12-2012, 20-12-2012,
% 28-11-2013
% Delft Institute of Applied Mathematics
% Delft University of Technology
%
% Copyright (c) reserved

N=A.n; 

rc=cellfun(@(x)size(x,2),A.D,'uni',false); % get the size of each elements in cells, i.e., the size of each D generators
rc=cat(1,rc{:});    % cat them in the 1st dimension to make it suitable for sum
rc=cumsum(rc);

GG=cell(1,N-1);
HH=cell(1,N-1);
vecx=cell(1,N);

%%%%%%%%%%%%%%%%%%%%%%%%% This is the norm way to do %%%%%%%%%%%%%%%%%%

k=1;
for i=N:-1:2
    if i==N
        GG{i-1}=A.V{i}'*x(rc(i-1)+1:rc(i));
        HH{k}=A.Q{k}'*x(1:rc(k));
        vecx{k}=x(1:rc(k));
        vecx{i}=x(rc(i-1)+1:rc(i));
    else
        GG{i-1}=A.V{i}'*x(rc(i-1)+1:rc(i))+A.W{i}*GG{i};
        HH{k}=A.Q{k}'*x(rc(k-1)+1:rc(k))+A.R{k}*HH{k-1};
        vecx{k}=x(rc(k-1)+1:rc(k));
    end
    k=k+1;
end


b1=cellfun(@mtimes,A.D,vecx,'uni',false);
b2=cellfun(@mtimes,A.P(2:end),HH,'uni',false);
b3=cellfun(@mtimes,A.U(1:end-1),GG,'uni',false);
[m,~]=size(A.D{1});
bz1=zeros(m,1);
[m,~]=size(A.D{N});
bz2=zeros(m,1);
b2=[{bz1} b2];
b3=[b3 {bz2}];
b=cellfun(@plus,b1,b2,'uni',false);
b=cellfun(@plus,b,b3,'uni',false);
b=cat(1,b{:});


end  
        
        
        
        
