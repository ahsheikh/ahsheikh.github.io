function [U]=SSSinvuptri(U)
% SSSinvuptri returns the inversion of an upper-triangular SSS matrix with
% SSS structure
%
% Syntax: U=SSSinvuptri(U), where U is an upper-triangular SSS matrox
%
% Written by Yue Qiu, 08-11-2013
% Delft Institute of Applied Mathematics
% Delft Center for Center and Control
% Delft University of Technology
%
% See also SSSinvlowtri
% Copyright (c) reserved

U=SSStranspose(U);
U=SSSinvlowtri(U);
U=SSStranspose(U);

end